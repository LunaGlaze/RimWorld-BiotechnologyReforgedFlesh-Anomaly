﻿using RimWorld;
using Verse;

namespace Luna_BRF_VEFAssemblies
{
    [DefOf]
    public static class LunaBRF_VEFDefof
    {
        public static JobDef BRF_RefuelDigesterIPipe;

        public static JobDef BRF_RefuelDigesterIPipe_Atomic;

        public static ThingDef BRF_DigesterIPipe;
    }
}
