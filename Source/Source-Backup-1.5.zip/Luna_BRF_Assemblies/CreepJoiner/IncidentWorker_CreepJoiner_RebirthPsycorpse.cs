﻿using RimWorld;

namespace Luna_BRF
{
    public class IncidentWorker_CreepJoiner_RebirthPsycorpse : IncidentWorker_GiveQuest
    {
        protected override bool CanFireNowSub(IncidentParms parms)
        {
            return base.CanFireNowSub(parms);
        }
    }
}
