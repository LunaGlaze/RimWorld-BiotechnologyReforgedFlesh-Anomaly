﻿using RimWorld;
using System.Collections.Generic;
using Verse;

namespace Luna_BRF
{
    public class CreepJoinerWorker_RebirthPsycorpseDownside : BaseCreepJoinerDownsideWorker
    {
        public override void OnCreated()
        {
            base.Pawn.health.AddHediff(LunaDefOf.BRF_RebirthPsycorpse_AngelsDescend);
        }

        public override void DoResponse(List<TargetInfo> looktargets, List<NamedArgument> namedArgs)
        {
        }
    }
}
