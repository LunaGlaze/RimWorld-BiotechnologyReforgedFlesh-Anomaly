﻿using Verse;

namespace Luna_BRF
{
    public class HediffCompProperties_InfectionsWithoutAkuloth : HediffCompProperties
    {
        public HediffCompProperties_InfectionsWithoutAkuloth()
        {
            compClass = typeof(HediffComp_InfectionsWithoutAkuloth);
        }
    }
}
