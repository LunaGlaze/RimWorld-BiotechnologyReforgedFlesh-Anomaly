﻿using RimWorld;

namespace Luna_BRF
{
    public class CompProperties_EntityNecrophagia : CompProperties_AbilityEffect
	{
		public CompProperties_EntityNecrophagia()
		{
			compClass = typeof(CompAbilityEffect_EntityNecrophagia);
		}
	}
}
