﻿using Verse;

namespace Luna_BRF
{
	public class CompProperties_NecrophagistEntity : CompProperties
	{
		public CompProperties_NecrophagistEntity()
		{
			compClass = typeof(CompNecrophagistEntity);
		}
	}
}
