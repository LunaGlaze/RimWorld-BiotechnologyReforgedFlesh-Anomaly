﻿using RimWorld;

namespace Luna_BRF
{
    public class CompProperties_BloodstainedTickParasitic : CompProperties_AbilityEffect
	{
		public CompProperties_BloodstainedTickParasitic()
		{
			compClass = typeof(CompAbilityEffect_BloodstainedTickParasitic);
		}
	}
}
