﻿using RimWorld;
using Verse;

namespace Luna_BRF
{
	public class CompProperties_ScarletCerebralJellyfish : CompProperties_AbilityEffect
	{
		public CompProperties_ScarletCerebralJellyfish()
		{
			compClass = typeof(CompAbilityEffect_ScarletCerebralJellyfish);
		}
	}
}
