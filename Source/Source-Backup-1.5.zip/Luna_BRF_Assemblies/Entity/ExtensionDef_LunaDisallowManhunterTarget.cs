﻿using Verse;

namespace Luna_BRF
{
    public class ExtensionDef_LunaDisallowManhunterTarget : DefModExtension
    {
        public bool disallowFindPawnTargetManhunter;
    }
}