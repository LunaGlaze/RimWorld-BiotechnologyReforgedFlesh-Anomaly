﻿using RimWorld;
using Verse;

namespace Luna_BRF
{
    public class CompProperties_WeaponDropManage : CompProperties
    {
        public CompProperties_WeaponDropManage()
        {
            compClass = typeof(CompLuna_WeaponDropManage);
        }
    }
}
